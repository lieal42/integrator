// MCIntegrator.cc

#include "MCIntegrator.hh"
#include <stdlib.h>
#include <time.h>

MCIntegrator::MCIntegrator(int n) : Integrator(n) {
    srand48(time(0));
}

double MCIntegrator::uniform(double a, double b) const {
    return a + (b - a) * lrand48() / RAND_MAX;
}

double MCIntegrator::point(double xlo, double xhi, int i) const {
        return uniform(xlo, xhi);
}
