// MCIntegrator.hh

#ifndef MCIntegrator_hh
#define MCIntegrator_hh

#include "Integrator.hh"

class MCIntegrator : public Integrator {
public:
    MCIntegrator(int n = 1000);

    virtual double point(double xlo, double xhi, int i) const;

private:
    double uniform(double a, double b) const;
};

#endif