// MidpointIntegrator.cc

#include "MidpointIntegrator.hh"

MidpointIntegrator::MidpointIntegrator(int n) : Integrator(n) {
}

double MidpointIntegrator::point(double xlo, double xhi, int i) const {
    double l = xhi - xlo;
    double dx = l / nPoints();
    double x;
    return xlo + ((double)i + 0.5) * dx;
}

