// app.cpp

#include <vector>
#include <iostream>
#include "Function.hh"
#include "Polynomial.hh"
#include "Exponential.hh"
#include "MCIntegrator.hh"
#include "MidpointIntegrator.hh"
#include "TGraph.h"
#include "TCanvas.h"
#include "TLegend.h"


int main(){
    int i,j;
    std::vector<double> coeff; // make a vector with coefficients (a0,a1,a2,...)
    coeff.push_back(1);
    coeff.push_back(3);
    coeff.push_back(2);
    coeff.push_back(6);
    Function* g = new Exponential("e",1,1);
    Function* f = new Polynomial("p", coeff);
    Integrator* mc = new MCIntegrator();
    Integrator* mp = new MidpointIntegrator();
    double mcintg[6], mpintg[6],mcintf[6], mpintf[6],x[6],resmcg[6],resmpg[6],resmcf[6],resmpf[6];
    double anintg = g->anIntegral(0,1), anintf = f->anIntegral(0,1);
    g->setIntegrator(mc);
    f->setIntegrator(mc);
    for(i=10, j=0;i<=1e6;i*=10,j++){
        mc->setNPoints(i);
        mcintg[j] = g->integrate(0,1);
        mcintf[j] = f->integrate(0,1);
        resmcg[j] = mcintg[j]-anintg;
        resmcf[j] = mcintf[j]-anintf;
        x[j]=j+1;
    }
    g->setIntegrator(mp);
    f->setIntegrator(mp);
    for( i=10,  j=0;i<=1e6;i*=10,j++){
        mp->setNPoints(i);
        mpintg[j] = g->integrate(0,1);
        mpintf[j] = f->integrate(0,1);
        resmpg[j] = mpintg[j]-anintg;
        resmpf[j] = mpintf[j]-anintf;
    }

    TGraph* gr1 = new TGraph(6,x,resmcg);
    TGraph* gr2 = new TGraph(6,x,resmpg);
    TGraph* gr3 = new TGraph(6,x,resmcf);
    TGraph* gr4 = new TGraph(6,x,resmpf);

    TLegend* l1 = new TLegend();
    TLegend* l2 = new TLegend();
    TLegend* l3 = new TLegend();
    TLegend* l4 = new TLegend();

    TCanvas* c1 = new TCanvas("c1", "exponential residuals",1024,800);
    gr1->SetTitle("Exponential Residuals (MC);log(#points);residual");
    l1->AddEntry(gr1,"MC integration");
    gr1->Draw();
    l1->Draw("SAME");
    c1->SaveAs("exponentialmc.pdf");

    TCanvas* c2 = new TCanvas("c2", "exponential residuals",1024,800);
    gr2->SetTitle("Exponential Residuals (MP);log(#points);residual");
    l2->AddEntry(gr2,"MP integration");
    gr2->Draw();
    l2->Draw("SAME");
    c2->SaveAs("exponentialmp.pdf");

    TCanvas* c3 = new TCanvas("c3", "polynomial residuals",1024,800);
    gr3->SetTitle("Polynomial Residuals (Mc);log(#points);residual");
    l3->AddEntry(gr3,"MC integration");
    gr3->Draw();
    l3->Draw("SAME");
    c3->SaveAs("polynomialmc.pdf");

    TCanvas* c4 = new TCanvas("c4", "polynomial residuals",1024,800);
    gr4->SetTitle("Polynomial Residuals (MP);log(#points);residual");
    l4->AddEntry(gr4,"MP integration");
    gr4->Draw();
    l4->Draw("SAME");
    // Ho provato in tutti i modi a sovrapporre i grafici, usando l'opzione "SAME" di Draw, in questo modo il programma compila ed esegue senza problemi
    // ma non disegna il secondo grafico da sovrapporre
    c4->SaveAs("polynomialmp.pdf");

    delete g;
    delete f;
    delete c1;
    delete c2;
    delete c3;
    delete c4;
    delete gr1;
    delete gr2;
    delete gr3;
    delete gr4;
    delete l1;
    delete l2;
    delete l3;
    delete l4;
}

